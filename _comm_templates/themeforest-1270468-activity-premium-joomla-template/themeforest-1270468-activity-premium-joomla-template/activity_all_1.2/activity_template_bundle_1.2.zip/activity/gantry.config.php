<?php
/**
 * @package 	Gantry Template Framework - RocketTheme
 * @version 	3.2.8 August 1, 2011
 * @author 		RocketTheme http://www.rockettheme.com
 * @copyright	Copyright (C) 2007 - 2011 RocketTheme, LLC
 * @license 	http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 *
 * Gantry uses the Joomla Framework (http://www.joomla.org), a GNU/GPLv2 content management system
 *
 */
defined('JPATH_BASE') or die();

$gantry_config_mapping = array(
    'belatedPNG' => 'belatedPNG',
	'ie6Warning' => 'ie6Warning'
);

$gantry_presets = array(
    'presets' => array(
        'preset01' => array(
            'name' => 'Style1',
			'activecolor' => '#9d3f35',
			
			//body styles
			'top-bgcolor' => '#5a2019',		
			
			//sub-menu fonts			
			'submymenufont-color' => '#ffffff',
			'submymenufont-bgcolor' => '#9d3f35',
			'submymenufont-hovercolor' => '#cccccc',
			'submymenufont-hoverbgcolor' => '#222222'			
        ),
		'preset02' => array(
            'name' => 'Style2',
			'activecolor' => '#576f3e',
			
			//body styles
			'top-bgcolor' => '#3e4f2c',		
			
			//sub-menu fonts			
			'submymenufont-color' => '#ffffff',
			'submymenufont-bgcolor' => '#576f3e',
			'submymenufont-hovercolor' => '#cccccc',
			'submymenufont-hoverbgcolor' => '#222222'			
        ),
		'preset03' => array(
            'name' => 'Style3',
			'activecolor' => '#c57139',
			
			//body styles
			'top-bgcolor' => '#a25d30',		
			
			//sub-menu fonts			
			'submymenufont-color' => '#ffffff',
			'submymenufont-bgcolor' => '#c57139',
			'submymenufont-hovercolor' => '#ffffff',
			'submymenufont-hoverbgcolor' => '#8f522a'			
        ),
		'preset04' => array(
            'name' => 'Style4',
			'activecolor' => '#4c6d81',
			
			//body styles
			'top-bgcolor' => '#314755',		
			
			//sub-menu fonts			
			'submymenufont-color' => '#ffffff',
			'submymenufont-bgcolor' => '#4c6d81',
			'submymenufont-hovercolor' => '#cccccc',
			'submymenufont-hoverbgcolor' => '#222222'			
        ),
		'preset05' => array(
            'name' => 'Style5',
			'activecolor' => '#417d70',
			
			//body styles
			'top-bgcolor' => '#315f55',		
			
			//sub-menu fonts			
			'submymenufont-color' => '#ffffff',
			'submymenufont-bgcolor' => '#417d70',
			'submymenufont-hovercolor' => '#cccccc',
			'submymenufont-hoverbgcolor' => '#222222'			
        )
    )
);

$gantry_browser_params = array(
    'ie6' => array(
        'backgroundlevel' => 'low',
        'bodylevel' => 'low'
    )
);

$gantry_belatedPNG = array('.png','#rt-logo');

$gantry_ie6Warning = "<h3>IE6 DETECTED: Currently Running in Compatibility Mode</h3><h4>This site is compatible with IE6, however your experience will be enhanced with a newer browser</h4><p>Internet Explorer 6 was released in August of 2001, and the latest version of IE6 was released in August of 2004.  By continuing to run Internet Explorer 6 you are open to any and all security vulnerabilities discovered since that date.  In March of 2009, Microsoft released version 8 of Internet Explorer that, in addition to providing greater security, is faster and more standards compliant than both version 6 and 7 that came before it.</p> <br /><a class='external'  href='http://www.microsoft.com/windows/internet-explorer/?ocid=ie8_s_cfa09975-7416-49a5-9e3a-c7a290a656e2'>Download Internet Explorer 8 NOW!</a>";
