<?php
/**
 * @package Gantry Template Framework - RocketTheme
 * @version 3.2.8 August 1, 2011
 * @author RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) 2007 - 2011 RocketTheme, LLC
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 *
 * Gantry uses the Joomla Framework (http://www.joomla.org), a GNU/GPLv2 content management system
 *
 */
// no direct access
defined( '_JEXEC' ) or die( 'Restricted index access' );

// load and inititialize gantry class
require_once('lib/gantry/gantry.php');



$headerheight = $gantry->get('headerheight'); 





?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $gantry->language; ?>" lang="<?php echo $gantry->language;?>" >
    <head>
        <?php
            $gantry->displayHead();
            $gantry->addStyles(array('template.css','joomla.css','style.css'));
        ?>
    </head>
    <body <?php echo $gantry->displayBodyTag(); ?>>
	
	
	
	
	<?php /** Star Top Container **/?>
		<div id="rt-top-container" style="min-height:<?php echo ('65' + $headerheight); ?>px;">	
		
		
				
				
		

		<?php /** Begin Header **/ if ($gantry->countModules('header')) : ?>
		<div id="rt-header">
			<div id="rt-header-inner">
			<div class="rt-container">				
				<?php echo $gantry->displayModules('header','standard','standard'); ?>
				<div class="clear"></div>
			</div>
			</div>
		</div>
		<?php /** End Header **/ endif; ?>
		
		
		
		<?php /** Begin Full Slider **/ if ($gantry->countModules('fullslider')) : ?>
		<div id="rt-full-slider">
			<?php echo $gantry->displayModules('fullslider','basic','basic'); ?>
			<div class="clear"></div>
		</div>
		<?php /** End Full Slider **/ endif; ?>
		
		
										
				
		
		
		<?php /** Begin Slider **/ if ($gantry->countModules('slider')) : ?>
		<div id="rt-slider" style="padding-top:<?php echo ('55' + $headerheight); ?>px;">
		<div class="rt-container">
				<?php echo $gantry->displayModules('slider','standard','standard'); ?>
				<div class="clear"></div>
		</div>
		</div>
		<?php /** End Slider **/ endif; ?>
				
		
		
		<?php /** Begin Showcase **/ if ($gantry->countModules('showcase')) : ?>
		<div id="rt-showcase" <?php if ($gantry->countModules('slider')) : ?> style="padding-top:0;" <?php else: ?> style="padding-top:<?php echo ('55' + $headerheight); ?>px;" <?php endif; ?>>		
			<div class="rt-container">
				<?php echo $gantry->displayModules('showcase','standard','standard'); ?>
				<div class="clear"></div>
			</div>
		</div>
		<?php /** End Showcase **/ endif; ?>
		
		
		<div class="clear"></div>
		</div>
		<?php /** End Top Container **/?>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		<?php /** Star Content Container **/?>
		<div id="rt-content-container">
		
		
		
		<?php /** Begin Breadcrumbs **/ if ($gantry->countModules('breadcrumb')) : ?>
		<div id="rt-breadcrumbs">
			<div class="rt-container">
				<?php echo $gantry->displayModules('breadcrumb','standard','standard'); ?>
				<div class="clear"></div>
			</div>
		</div>
		<?php /** End Breadcrumbs **/ endif; ?>		
		
		
		
		
		
		<?php /** Begin Feature **/ if ($gantry->countModules('features')) : ?>
		<div id="rt-features" <?php if ($gantry->countModules('breadcrumb')) : ?> style="margin-top:-40px;"<?php endif; ?>>
			<div class="rt-container">
				<?php echo $gantry->displayModules('features','standard','standard'); ?>
				<div class="clear"></div>
			</div>
		</div>
		<?php /** End Feature **/ endif; ?>
		
		
		
		<?php /** Begin Main Top **/ if ($gantry->countModules('maintop')) : ?>
		<div id="rt-maintop">
			<div class="rt-container">
				<?php echo $gantry->displayModules('maintop','standard','standard'); ?>
				<div class="clear"></div>
			</div>
		</div>
		<?php /** End Main Top **/ endif; ?>
		<?php /** Begin Main Body **/ ?>
	    <?php echo $gantry->displayMainbody('mainbody','sidebar','standard','standard','standard','standard','standard'); ?>
		<?php /** End Main Body **/ ?>
		
		
		
		<?php /** Begin Utility **/ if ($gantry->countModules('utility')) : ?>
		<div id="rt-utility">
			<div class="rt-container">
				<?php echo $gantry->displayModules('utility','basic','basic'); ?>
				<div class="clear"></div>
			</div>
		</div>
		<?php /** End Utility **/ endif; ?>	
		
		
		
		
		
		
		<?php /** Begin Main Bottom **/ if ($gantry->countModules('mainbottom')) : ?>
		<div id="rt-mainbottom">
			<div class="rt-container">
				<?php echo $gantry->displayModules('mainbottom','standard','standard'); ?>
				<div class="clear"></div>
			</div>
		</div>
		<?php /** End Main Bottom **/ endif; ?>		
		
		
		
		</div>
		<?php /** End Content Container **/?>
		
		
		
		
		
		
		
		
		<?php /** Star Bottom Container **/?>
		<div id="rt-bottom-container">
		
		
		
		<?php /** Begin Bottom **/ if ($gantry->countModules('bottom')) : ?>
		<div id="rt-bottom">
			<div class="rt-container">
				<?php echo $gantry->displayModules('bottom','standard','standard'); ?>
				<div class="clear"></div>
			</div>
		</div>
		<?php /** End Bottom **/ endif; ?>		
		
		
		
			
		
		<?php /** Begin Footer **/ if ($gantry->countModules('footer')) : ?>
		<div id="rt-footer">	
			<div class="rt-container">
				<?php echo $gantry->displayModules('footer','standard','standard'); ?>
				<div class="clear"></div>
			</div>
		</div>		
		<?php /** End Footer **/ endif; ?>
		
		
		<?php /** Begin Copyright **/ if ($gantry->countModules('copyright')) : ?>
		<div id="rt-copyright">	
			<div class="rt-container">
				<?php echo $gantry->displayModules('copyright','standard','standard'); ?>
				<div class="clear"></div>
			</div>
		</div>
		<?php /** End Copyright **/ endif; ?>
		<?php /** Begin Debug **/ if ($gantry->countModules('debug')) : ?>
		<div id="rt-debug">	
			<div class="rt-container">
				<?php echo $gantry->displayModules('debug','standard','standard'); ?>
				<div class="clear"></div>
			</div>
		</div>
		<?php /** End Debug **/ endif; ?>		
		
		
		
		
		
		
		</div>
		<?php /** End Bottom Container **/?>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		<?php /** Begin Analytics **/ if ($gantry->countModules('analytics')) : ?>
		<?php echo $gantry->displayModules('analytics','basic','basic'); ?>
		<?php /** End Analytics **/ endif; ?>
	
	
	</body>
</html>
<?php
$gantry->finalize();
?>