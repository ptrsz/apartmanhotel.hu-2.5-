<?php
/**
 * @version   1.8 December 15, 2011
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) 2007 - 2011 RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

//require_once (dirname(__FILE__).DS.'RokNavMenuTree.php');

/*
 * Created on Jan 16, 2009
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
class BaseRokNavMenuTemplateParams {
	function getTemplateParams($basename, $base_control_name, &$params){ 
		return "";	
	}
}