<?php
/**
 * @package     gantry
 * @subpackage  features
 * @version		3.2.8 August 1, 2011
 * @author		RocketTheme http://www.rockettheme.com
 * @copyright 	Copyright (C) 2007 - 2011 RocketTheme, LLC
 * @license		http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 *
 * Gantry uses the Joomla Framework (http://www.joomla.org), a GNU/GPLv2 content management system
 *
 */

defined('JPATH_BASE') or die();

gantry_import('core.gantryfeature');

/**
 * @package     gantry
 * @subpackage  features
 */
class GantryFeatureStyleDeclaration extends GantryFeature {
var $_feature_name = 'styledeclaration';

function isEnabled() {
global $gantry;
$menu_enabled = $this->get('enabled');
if (1 == (int)$menu_enabled) return true;
return false;
}

function init() {
global $gantry;








//////////////////////////////////LOGO///////////////////////////////////////
$css = 'a#rt-logo {
	background:url('.JURI::base().'images/'.$gantry->get('logoimage').') no-repeat left top;
	height:'.$gantry->get('logoheight').'px;
	width:'.$gantry->get('logowidth').'px;
	margin:'.$gantry->get('logomargin').';
}
';		












//////////////////////////////////TOP///////////////////////////////////////
$css .= '#rt-top-container {
	background-color:'.$gantry->get('top-bgcolor').';
	background-image:url('.JURI::base().'images/'.$gantry->get('top-bgimage').');
	background-repeat:'.$gantry->get('top-bgrepeat').';
	background-position:'.$gantry->get('top-bgposition').';
	background-attachment:'.$gantry->get('top-bgattachment').';
}
';
	
$css .= '#rt-top-container h1, 
#rt-top-container h2, 
#rt-top-container h3, 
#rt-top-container h4, 
#rt-top-container h5, 
#rt-top-container h6 {
	color:'.$gantry->get('top-headingscolor').';
}
';

$css .= '#rt-top-container,
#rt-header,
#rt-showcase,
#rt-top-container .inputbox, 
#rt-top-container input, 
#rt-top-container textarea  {
	color:'.$gantry->get('top-textcolor').';
}
';

$css .= '#rt-top-container a {
	color:'.$gantry->get('top-linkcolor').';
	text-decoration:'.$gantry->get('top-linkunderline').';
}
';

$css .= '#rt-top-container a:hover, 
#rt-top-container a:active, 
#rt-top-container a:focus {
	color:'.$gantry->get('top-linkhovercolor').';
	text-decoration:'.$gantry->get('top-linkhoverunderline').';
}
';








///////ACTIVE COLOR////////
$css .= '#rt-header-inner,
#rt-content-container,
#rt-footer {
	border-color:'.$gantry->get('activecolor').';
}
';


$css .= 'a.readon,
.catItemReadMore a,
.userItemReadMore a,
.latestItemReadMore a,
.genericItemReadMore a,
.tagItemReadMore a,
a.slide-link,
.button,
a.button-small,
a.button-big {
	background-color:'.$gantry->get('activecolor').';
}
';




//////////////////////////////////FONT///////////////////////////////////////
$css .= 'body {
	font-size:'.$gantry->get('bodyfont-size').';
}
';


		
//////////////////////////////////HEADINGS///////////////////////////////////////
$css .= 'h1, 
.component-content 
.title, 
h2.title {
	font-size:'.$gantry->get('headingsfont-h1size').';
}
';
$css .= 'h2 {
	font-size:'.$gantry->get('headingsfont-h2size').';
}
';
$css .= 'h3 {
	font-size:'.$gantry->get('headingsfont-h3size').';
}
';
$css .= 'h4, 
.module-title h2 {
	font-size:'.$gantry->get('headingsfont-h4size').';
}
';
$css .= 'h5 {
	font-size:'.$gantry->get('headingsfont-h5size').';
}
';
$css .= 'h6 {
	font-size:'.$gantry->get('headingsfont-h6size').';
}
';		
$css .= 'h1, 
h2, 
h3, 
h4, 
h5, 
h6, 
.slide-title {
	text-transform:'.$gantry->get('headingsfont-texttransform').';
}
';
$css .= 'h1, 
h2, 
h3, 
h4, 
h5, 
h6, 
.slide-title {
	font-weight:'.$gantry->get('headingsfont-fontweight').';
}
';
$css .= 'h1, 
h2, 
h3, 
h4, 
h5, 
h6, 
.slide-title {
	font-style:'.$gantry->get('headingsfont-fontstyle').';
}
';










		
//////////////////////////////////MENU///////////////////////////////////////
$css .= '#rt-top-container #rt-menu ul.menu li a, 
#rt-top-container .menutop li.root > .item, 
#rt-top-container .menu-type-splitmenu .menutop li .item {
	font-size:'.$gantry->get('mymenufont-mymenufontsize').';
	text-transform:'.$gantry->get('mymenufont-mymenutexttransform').';
	font-weight:'.$gantry->get('mymenufont-mymenufontweight').';
	font-style:'.$gantry->get('mymenufont-mymenufontstyle').';
	color:'.$gantry->get('mymenufont-color').';
}
';


$css .= '#rt-top-container #rt-menu ul.menu li a:hover, 
#rt-top-container .menutop li.root > .item:hover, 
#rt-top-container .menutop li.active.root.f-mainparent-itemfocus > .item, 
#rt-top-container .menutop li.root.f-mainparent-itemfocus > .item, 
#rt-top-container .menu-type-splitmenu .menutop li:hover > .item {	
	color:'.$gantry->get('mymenufont-hovercolor').';
}
';

$css .= '#rt-top-container #rt-menu ul.menu li.active a, 
#rt-top-container #rt-menu ul.menu li.active a:hover, 
#rt-top-container .menutop li.root.active > .item, 
#rt-top-container .menutop li.root.active > .item:hover, 
#rt-top-container .menu-type-splitmenu .menutop li.active .item{
	color:'.$gantry->get('mymenufont-activecolor').';
}
';
	



	
	
	
	

$css .= '.menutop li.root > .item {
	height:'.$gantry->get('headerheight').'px!important;
}
';

$css .= '.menutop li.root > .item span {
	line-height:'.$gantry->get('headerheight').'px!important;
}
';
















	
		
//sub-menu	
$css .= '.menutop .fusion-submenu-wrapper {
	background-color:'.$gantry->get('submymenufont-bgcolor').';
}
';

	
$css .= '.menutop ul li > .item {
	font-size:'.$gantry->get('submymenufont-submymenufontsize').';
	text-transform:'.$gantry->get('submymenufont-submymenutexttransform').';
	font-weight:'.$gantry->get('submymenufont-submymenufontweight').';
	font-style:'.$gantry->get('submymenufont-submymenufontstyle').';
	color:'.$gantry->get('submymenufont-color').';
}
';


$css .= '.menutop ul li > .item:hover, 
.menutop ul li.f-menuparent-itemfocus > .item {
	color:'.$gantry->get('submymenufont-hovercolor').';
	background-color:'.$gantry->get('submymenufont-hoverbgcolor').';
}
';














//////////////////////////////////CONTENT SECTION///////////////////////////////////////		
$css .= '#rt-content-container h1, 
#rt-content-container h2, 
#rt-content-container h3, 
#rt-content-container h4, 
#rt-content-container h5, 
#rt-content-container h6 {
	color:'.$gantry->get('content-headingscolor').';
}
';

$css .= '.gkHighlighterInterface span.text {
color:'.$gantry->get('content-headingscolor').'!important;
}
';

$css .= '#rt-content-container,
#rt-content-container #rt-header, 
#rt-content-container .inputbox, 
#rt-content-container textarea  {
	color:'.$gantry->get('content-textcolor').';
}
';

$css .= '#rt-content-container a,
#rt-content-container .nsp2 .nspArt a.readon {
	color:'.$gantry->get('content-linkcolor').';
	text-decoration:'.$gantry->get('content-linkunderline').';
}
';

$css .= '#rt-content-container a:hover, 
#rt-content-container a:active, 
#rt-content-container a:focus,
#rt-content-container .nsp2 .nspArt a.readon:hover,
#rt-content-container .nsp2 .nspArt a.readon:active,
#rt-content-container .nsp2 .nspArt a.readon:focus {
	color:'.$gantry->get('content-linkhovercolor').';
	text-decoration:'.$gantry->get('content-linkhoverunderline').';
}
';



















//////////////////////////////////BOTTOM CONTAINER///////////////////////////////////////
$css .='#rt-bottom-container {
	background-color:'.$gantry->get('bottom-bgcolor').';
}
';
		
$css .= '#rt-bottom-container h1, 
#rt-bottom-container h2, 
#rt-bottom-container h3, 
#rt-bottom-container h4, 
#rt-bottom-container h5, 
#rt-bottom-container h6 {
	color:'.$gantry->get('bottom-headingscolor').';
}
';

$css .= '#rt-bottom-container, 
#rt-bottom-container .inputbox, 
#rt-bottom-container textarea,
#rt-footer,
#rt-debug  {
	color:'.$gantry->get('bottom-textcolor').';
}
';

$css .= '#rt-bottom-container a,
#rt-bottom-container .nsp2 .nspArt a.readon {
	color:'.$gantry->get('bottom-linkcolor').';
	text-decoration:'.$gantry->get('bottom-linkunderline').';
}
';

$css .= '#rt-bottom-container a:hover, 
#rt-bottom-container a:active, 
#rt-bottom-container a:focus,
#rt-bottom-container .nsp2 .nspArt a.readon:hover,
#rt-bottom-container .nsp2 .nspArt a.readon:active,
#rt-bottom-container .nsp2 .nspArt a.readon:focus {
	color:'.$gantry->get('bottom-linkhovercolor').';
	text-decoration:'.$gantry->get('bottom-linkhoverunderline').';
}
';


 

      
        
$gantry->addInlineStyle($css);

}

}