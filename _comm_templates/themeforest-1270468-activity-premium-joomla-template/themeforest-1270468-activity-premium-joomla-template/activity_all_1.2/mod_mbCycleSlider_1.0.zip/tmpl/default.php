<?php 

/**
* @package   Elastic Slideshow
* @copyright Copyright (C) 2009 - 2010 mariuszboloz.com All rights reserved.
* @license   Commercial
* Contact to : mariuszboloz@gmail.com
**/
?>

<?php
defined('_JEXEC') or die('Restricted access'); 
$doc =& JFactory::getDocument(); 
?>


<!-- PARAMETERS DECLARATIONS -->
<?php
$jquery				= $params->get( 'jquery' );
$timeout			= $params->get( 'timeout' );
$speed				= $params->get( 'speed' );
$slidetype			= $params->get( 'slidetype' );
$nav				= $params->get( 'nav' );
$height				= $params->get( 'height' );
$font_family		= $params->get( 'font_family' );
$font_enabler		= $params->get( 'font_enabler' );


$slide1_img			= $params->get( 'slide1_img' );
$slide1_link		= $params->get( 'slide1_link' );
$slide1_target		= $params->get( 'slide1_target' );
$slide1_title		= $params->get( 'slide1_title' );
$slide1_desc		= $params->get( 'slide1_desc' );
$slide1_padding		= $params->get( 'slide1_padding' );
$slide1_align		= $params->get( 'slide1_align' );
$slide1_textlink	= $params->get( 'slide1_textlink' );
$slide1_headingsize	= $params->get( 'slide1_headingsize' );
$slide1_textsize	= $params->get( 'slide1_textsize' );

$slide2_img			= $params->get( 'slide2_img' );
$slide2_link		= $params->get( 'slide2_link' );
$slide2_target		= $params->get( 'slide2_target' );
$slide2_title		= $params->get( 'slide2_title' );
$slide2_desc		= $params->get( 'slide2_desc' );
$slide2_padding		= $params->get( 'slide2_padding' );
$slide2_align		= $params->get( 'slide2_align' );
$slide2_textlink	= $params->get( 'slide2_textlink' );
$slide2_headingsize	= $params->get( 'slide2_headingsize' );
$slide2_textsize	= $params->get( 'slide2_textsize' );

$slide3_img			= $params->get( 'slide3_img' );
$slide3_link		= $params->get( 'slide3_link' );
$slide3_target		= $params->get( 'slide3_target' );
$slide3_title		= $params->get( 'slide3_title' );
$slide3_desc		= $params->get( 'slide3_desc' );
$slide3_padding		= $params->get( 'slide3_padding' );
$slide3_align		= $params->get( 'slide3_align' );
$slide3_textlink	= $params->get( 'slide3_textlink' );
$slide3_headingsize	= $params->get( 'slide3_headingsize' );
$slide3_textsize	= $params->get( 'slide3_textsize' );

$slide4_img			= $params->get( 'slide4_img' );
$slide4_link		= $params->get( 'slide4_link' );
$slide4_target		= $params->get( 'slide4_target' );
$slide4_title		= $params->get( 'slide4_title' );
$slide4_desc		= $params->get( 'slide4_desc' );
$slide4_padding		= $params->get( 'slide4_padding' );
$slide4_align		= $params->get( 'slide4_align' );
$slide4_textlink	= $params->get( 'slide4_textlink' );
$slide4_headingsize	= $params->get( 'slide4_headingsize' );
$slide4_textsize	= $params->get( 'slide4_textsize' );

$slide5_img			= $params->get( 'slide5_img' );
$slide5_link		= $params->get( 'slide5_link' );
$slide5_target		= $params->get( 'slide5_target' );
$slide5_title		= $params->get( 'slide5_title' );
$slide5_desc		= $params->get( 'slide5_desc' );
$slide5_padding		= $params->get( 'slide5_padding' );
$slide5_align		= $params->get( 'slide5_align' );
$slide5_textlink	= $params->get( 'slide5_textlink' );
$slide5_headingsize	= $params->get( 'slide5_headingsize' );
$slide5_textsize	= $params->get( 'slide5_textsize' );

$slide6_img			= $params->get( 'slide6_img' );
$slide6_link		= $params->get( 'slide6_link' );
$slide6_target		= $params->get( 'slide6_target' );
$slide6_title		= $params->get( 'slide6_title' );
$slide6_desc		= $params->get( 'slide6_desc' );
$slide6_padding		= $params->get( 'slide6_padding' );
$slide6_align		= $params->get( 'slide6_align' );
$slide6_textlink	= $params->get( 'slide6_textlink' );
$slide6_headingsize	= $params->get( 'slide6_headingsize' );
$slide6_textsize	= $params->get( 'slide6_textsize' );

$slide7_img			= $params->get( 'slide7_img' );
$slide7_link		= $params->get( 'slide7_link' );
$slide7_target		= $params->get( 'slide7_target' );
$slide7_title		= $params->get( 'slide7_title' );
$slide7_desc		= $params->get( 'slide7_desc' );
$slide7_padding		= $params->get( 'slide7_padding' );
$slide7_align		= $params->get( 'slide7_align' );
$slide7_textlink	= $params->get( 'slide7_textlink' );
$slide7_headingsize	= $params->get( 'slide7_headingsize' );
$slide7_textsize	= $params->get( 'slide7_textsize' );


?>
<!-- //PARAMETERS DECLARATIONS -->





<!-- SCRIPTS AND STYLES -->
<?php
$doc->addStyleSheet("modules/mod_mbCycleSlider/css/style.css");

if ($font_enabler=='1'): {
$doc->addStyleSheet("http://fonts.googleapis.com/css?family=".$font_family."");
$doc->addStyleDeclaration ("
h2.slide-heading,
p.slide-desc				{font-family:'".$font_family."', Arial, 'Helvetica', serif;}
");
}
endif;


$doc->addStyleDeclaration ("
div#slider					{height:".$height.";}
div#slider ul li			{height:".$height.";}
#rt-top-container			{height:".$height.";}
");

if($jquery=='1') : {
$doc->addScript("http://ajax.googleapis.com/ajax/libs/jquery/1.7.0/jquery.min.js");
}
endif;
$doc->addScript("modules/mod_mbCycleSlider/js/jquery.cycle.all.js");

$doc->addScriptDeclaration("
	$(document).ready(function(){
	$('#slider ul').cycle({
		
		'prev': 		$('#prev'),
		'next': 		$('#next'),
		'fx': 			'".$slidetype."', 
		'timeout': 		".$timeout.",
		'speed': 		".$speed."
	});
	
});

");
?>
<!-- //SCRIPTS AND STYLES -->



<!-- CYCLE SLIDER -->
<div id="slider">
	<ul>
	
	
	
	
	
		<?php if($slide1_img !='') : ?>
		
		<!-- SLIDE1 -->
		
		<li style="background:url(<?php echo $slide1_img ?>) no-repeat center top;">
			<div class="rt-container">
				<div class="slide-content" style="padding:<?php echo $slide1_padding ?>;text-align:<?php echo $slide1_align ?>;">
				
					<?php if($slide1_title !='') : ?>
						<h2 class="slide-heading" style="font-size:<?php echo $slide1_headingsize ?>"><?php echo $slide1_title ?></h2>
					<?php endif; ?>
					
					<?php if($slide1_desc !='') : ?>
						<p class="slide-desc" style="font-size:<?php echo $slide1_textsize ?>"><?php echo $slide1_desc ?></p>
					<?php endif; ?>
					
					<?php if($slide1_link !='') : ?>
						<a href="<?php echo $slide1_link ?>" class="slide-link" target="<?php echo $slide1_target ?>" <?php if ($slide1_align == 'right'): ?> style="float:right;" <?php endif; ?> ><?php echo $slide1_textlink ?></a>
					<?php endif; ?>					
					
				</div>
			</div>
		</li>
		
		<!-- //SLIDE1 -->
		
		<?php endif; ?>
		
		
		
		
		<?php if($slide2_img !='') : ?>
		
		<!-- SLIDE2 -->
		
		<li style="background:url(<?php echo $slide2_img ?>) no-repeat center top;">
			<div class="rt-container">
				<div class="slide-content" style="padding:<?php echo $slide2_padding ?>;text-align:<?php echo $slide2_align ?>;">
				
					<?php if($slide2_title !='') : ?>
						<h2 class="slide-heading" style="font-size:<?php echo $slide2_headingsize ?>"><?php echo $slide2_title ?></h2>
					<?php endif; ?>
					
					<?php if($slide2_desc !='') : ?>
						<p class="slide-desc" style="font-size:<?php echo $slide2_textsize ?>"><?php echo $slide2_desc ?></p>
					<?php endif; ?>
					
					<?php if($slide2_link !='') : ?>
						<a href="<?php echo $slide2_link ?>" class="slide-link" target="<?php echo $slide2_target ?>" <?php if ($slide2_align == 'right'): ?> style="float:right;" <?php endif; ?>><?php echo $slide2_textlink ?></a>
					<?php endif; ?>					
					
				</div>
			</div>
		</li>
		
		<!-- //SLIDE2 -->
		
		<?php endif; ?>
		
		
		
		
		
		
		
		
		
		
		<?php if($slide3_img !='') : ?>
		
		<!-- SLIDE3 -->
		
		<li style="background:url(<?php echo $slide3_img ?>) no-repeat center top;">
			<div class="rt-container">
				<div class="slide-content" style="padding:<?php echo $slide3_padding ?>;text-align:<?php echo $slide3_align ?>;">
				
					<?php if($slide3_title !='') : ?>
						<h2 class="slide-heading" style="font-size:<?php echo $slide3_headingsize ?>"><?php echo $slide3_title ?></h2>
					<?php endif; ?>
					
					<?php if($slide3_desc !='') : ?>
						<p class="slide-desc" style="font-size:<?php echo $slide3_textsize ?>"><?php echo $slide3_desc ?></p>
					<?php endif; ?>
					
					<?php if($slide3_link !='') : ?>
						<a href="<?php echo $slide3_link ?>" class="slide-link" target="<?php echo $slide3_target ?>" <?php if ($slide3_align == 'right'): ?> style="float:right;" <?php endif; ?>><?php echo $slide3_textlink ?></a>
					<?php endif; ?>					
					
				</div>
			</div>
		</li>
		
		<!-- //SLIDE3 -->
		
		<?php endif; ?>
		
		
		
		
		
		
		
		
		<?php if($slide4_img !='') : ?>
		
		<!-- SLIDE4 -->
		
		<li style="background:url(<?php echo $slide4_img ?>) no-repeat center top;">
			<div class="rt-container">
				<div class="slide-content" style="padding:<?php echo $slide4_padding ?>;text-align:<?php echo $slide4_align ?>;">
				
					<?php if($slide4_title !='') : ?>
						<h2 class="slide-heading" style="font-size:<?php echo $slide4_headingsize ?>"><?php echo $slide4_title ?></h2>
					<?php endif; ?>
					
					<?php if($slide4_desc !='') : ?>
						<p class="slide-desc" style="font-size:<?php echo $slide4_textsize ?>"><?php echo $slide4_desc ?></p>
					<?php endif; ?>
					
					<?php if($slide4_link !='') : ?>
						<a href="<?php echo $slide4_link ?>" class="slide-link" target="<?php echo $slide4_target ?>" <?php if ($slide4_align == 'right'): ?> style="float:right;" <?php endif; ?>><?php echo $slide4_textlink ?></a>
					<?php endif; ?>					
					
				</div>
			</div>
		</li>
		
		<!-- //SLIDE4 -->
		
		<?php endif; ?>
		
		
		
		
		
		
		
		
		<?php if($slide5_img !='') : ?>
		
		<!-- SLIDE5 -->
		
		<li style="background:url(<?php echo $slide5_img ?>) no-repeat center top;">
			<div class="rt-container">
				<div class="slide-content" style="padding:<?php echo $slide5_padding ?>;text-align:<?php echo $slide5_align ?>;">
				
					<?php if($slide5_title !='') : ?>
						<h2 class="slide-heading" style="font-size:<?php echo $slide5_headingsize ?>"><?php echo $slide5_title ?></h2>
					<?php endif; ?>
					
					<?php if($slide5_desc !='') : ?>
						<p class="slide-desc" style="font-size:<?php echo $slide5_textsize ?>"><?php echo $slide5_desc ?></p>
					<?php endif; ?>
					
					<?php if($slide5_link !='') : ?>
						<a href="<?php echo $slide5_link ?>" class="slide-link" target="<?php echo $slide5_target ?>" <?php if ($slide5_align == 'right'): ?> style="float:right;" <?php endif; ?>><?php echo $slide5_textlink ?></a>
					<?php endif; ?>					
					
				</div>
			</div>
		</li>
		
		<!-- //SLIDE5 -->
		
		<?php endif; ?>
		
		
		
		
		
		
		
		
		<?php if($slide6_img !='') : ?>
		
		<!-- SLIDE6 -->
		
		<li style="background:url(<?php echo $slide6_img ?>) no-repeat center top;">
			<div class="rt-container">
				<div class="slide-content" style="padding:<?php echo $slide6_padding ?>;text-align:<?php echo $slide6_align ?>;">
				
					<?php if($slide6_title !='') : ?>
						<h2 class="slide-heading" style="font-size:<?php echo $slide6_headingsize ?>"><?php echo $slide6_title ?></h2>
					<?php endif; ?>
					
					<?php if($slide6_desc !='') : ?>
						<p class="slide-desc" style="font-size:<?php echo $slide6_textsize ?>"><?php echo $slide6_desc ?></p>
					<?php endif; ?>
					
					<?php if($slide6_link !='') : ?>
						<a href="<?php echo $slide6_link ?>" class="slide-link" target="<?php echo $slide6_target ?>" <?php if ($slide6_align == 'right'): ?> style="float:right;" <?php endif; ?>><?php echo $slide6_textlink ?></a>
					<?php endif; ?>					
					
				</div>
			</div>
		</li>
		
		<!-- //SLIDE6 -->
		
		<?php endif; ?>
		
		
		
		
		
		
		
		
		<?php if($slide7_img !='') : ?>
		
		<!-- SLIDE7 -->
		
		<li style="background:url(<?php echo $slide7_img ?>) no-repeat center top;">
			<div class="rt-container">
				<div class="slide-content" style="padding:<?php echo $slide7_padding ?>;text-align:<?php echo $slide7_align ?>;">
				
					<?php if($slide7_title !='') : ?>
						<h2 class="slide-heading" style="font-size:<?php echo $slide7_headingsize ?>"><?php echo $slide7_title ?></h2>
					<?php endif; ?>
					
					<?php if($slide7_desc !='') : ?>
						<p class="slide-desc" style="font-size:<?php echo $slide7_textsize ?>"><?php echo $slide7_desc ?></p>
					<?php endif; ?>
					
					<?php if($slide7_link !='') : ?>
						<a href="<?php echo $slide7_link ?>" class="slide-link" target="<?php echo $slide7_target ?>" <?php if ($slide7_align == 'right'): ?> style="float:right;" <?php endif; ?>><?php echo $slide7_textlink ?></a>
					<?php endif; ?>					
					
				</div>
			</div>
		</li>
		
		<!-- //SLIDE7 -->
		
		<?php endif; ?>
		
		
		
		
				
		
		
		
	</ul>
	
	<?php if($nav =='1') : ?>

	<!-- NAVIGATION -->
				
	<div id="slider-nav">
		<a id="prev"></a>
		<a id="next"></a>
	</div>

	<!-- //NAVIGATION -->
	
<?php endif; ?>
	
	
	
	
</div>
				




<!-- //CYCLE SLIDER -->